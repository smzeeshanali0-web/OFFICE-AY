package com.oabulk;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Shared in-process state (main thread only). Results are persisted in SharedPreferences. */
final class Store {
    static final String BASE_URL = "https://sc.officeally.com/verify-eligibility/transaction/";

    static final String[] COLUMNS = {
            "Transaction ID", "Member Name", "Member ID", "Date of Birth", "Gender", "Address",
            "Group Number", "Plan Begin Date", "Plan Name", "Payer", "Coverage Status", "Identifier Code"
    };

    interface Listener { void onChange(); }

    static Listener listener;
    static boolean running = false;
    static String status = "Idle";
    static List<String> pendingUrls = new ArrayList<>();

    static final List<JSONObject> results = new ArrayList<>(); // {seq, d:{...}}
    static final List<String> failed = new ArrayList<>();
    static final List<String> logs = new ArrayList<>();

    private static SharedPreferences prefs;
    private static boolean loaded = false;

    static void init(Context c) {
        if (loaded) return;
        prefs = c.getApplicationContext().getSharedPreferences("store", Context.MODE_PRIVATE);
        try {
            JSONArray a = new JSONArray(prefs.getString("results", "[]"));
            for (int i = 0; i < a.length(); i++) results.add(a.getJSONObject(i));
            JSONArray f = new JSONArray(prefs.getString("failed", "[]"));
            for (int i = 0; i < f.length(); i++) failed.add(f.getString(i));
        } catch (Exception ignored) { }
        loaded = true;
    }

    static void persist() {
        if (prefs == null) return;
        JSONArray a = new JSONArray();
        for (JSONObject o : results) a.put(o);
        JSONArray f = new JSONArray();
        for (String s : failed) f.put(s);
        prefs.edit().putString("results", a.toString()).putString("failed", f.toString()).apply();
    }

    static int nextSeq() {
        int m = -1;
        for (JSONObject o : results) m = Math.max(m, o.optInt("seq", -1));
        return m + 1;
    }

    static void addResult(int seq, JSONObject data) {
        try {
            JSONObject o = new JSONObject();
            o.put("seq", seq);
            o.put("d", data);
            results.add(o);
        } catch (Exception ignored) { }
        persist();
        changed();
    }

    static void setFailed(List<String> urls) {
        failed.clear();
        failed.addAll(urls);
        persist();
        changed();
    }

    static void clearAll() {
        results.clear();
        failed.clear();
        persist();
        changed();
    }

    static void setStatus(String s) {
        status = s;
        changed();
    }

    static void log(String text, boolean error) {
        String t = new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date());
        logs.add(t + (error ? "  ✗ " : "  ") + text);
        while (logs.size() > 40) logs.remove(0);
        changed();
    }

    static void changed() {
        if (listener != null) listener.onChange();
    }

    static List<JSONObject> sortedResults() {
        List<JSONObject> copy = new ArrayList<>(results);
        Collections.sort(copy, new Comparator<JSONObject>() {
            @Override public int compare(JSONObject a, JSONObject b) {
                return Integer.compare(a.optInt("seq"), b.optInt("seq"));
            }
        });
        return copy;
    }

    private static String q(String v) {
        return "\"" + (v == null ? "" : v.replace("\"", "\"\"")) + "\"";
    }

    static String buildCsv() {
        StringBuilder sb = new StringBuilder("\ufeff");
        for (int i = 0; i < COLUMNS.length; i++) {
            sb.append(q(COLUMNS[i])).append(',');
        }
        sb.append(q("Non Downloaded Links")).append('\n');
        List<JSONObject> rows = sortedResults();
        int n = Math.max(rows.size(), failed.size());
        for (int i = 0; i < n; i++) {
            JSONObject d = i < rows.size() ? rows.get(i).optJSONObject("d") : null;
            for (String c : COLUMNS) {
                sb.append(q(d == null ? "" : d.optString(c, ""))).append(',');
            }
            sb.append(q(i < failed.size() ? failed.get(i) : "")).append('\n');
        }
        return sb.toString();
    }
}
