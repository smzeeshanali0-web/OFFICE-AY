package com.oabulk;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.io.InputStream;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

/** Runs N hidden WebViews in parallel (main thread). Each link gets a fresh WebView. */
final class ScrapeEngine {
    static final String DESKTOP_UA =
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";
    private static final long MAX_MS = 150000;

    interface Done { void onDone(); }

    private static final class Item {
        final String url; final int seq;
        Item(String u, int s) { url = u; seq = s; }
    }

    private static final class Job {
        Item item; WebView wv;
        long start = System.currentTimeMillis();
        long coreSince = 0;
        int reloaded = 0;
        boolean finished = false;
        boolean evaluating = false;
    }

    private final Context ctx;
    private final int conc;
    private final Done done;
    private final String js;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final ArrayDeque<Item> queue = new ArrayDeque<>();
    private final List<Job> jobs = new ArrayList<>();
    private List<Item> failed = new ArrayList<>();
    private boolean stopped = false;
    private boolean ended = false;
    private boolean loginWarned = false;
    private int retryRound = 0;
    private int total = 0;
    private int doneCount = 0;
    private String label = "Pass 1";

    ScrapeEngine(Context ctx, int conc, Done done) {
        this.ctx = ctx;
        this.conc = Math.max(1, Math.min(15, conc));
        this.done = done;
        this.js = readAsset("scrape.js");
    }

    private String readAsset(String name) {
        try (InputStream in = ctx.getAssets().open(name)) {
            byte[] b = new byte[in.available()];
            int off = 0;
            while (off < b.length) {
                int r = in.read(b, off, b.length - off);
                if (r < 0) break;
                off += r;
            }
            return new String(b, "UTF-8");
        } catch (Exception e) {
            return "null";
        }
    }

    void start(List<String> urls) {
        int base = Store.nextSeq();
        for (int i = 0; i < urls.size(); i++) queue.add(new Item(urls.get(i), base + i));
        total = queue.size();
        Store.failed.clear();
        Store.log("Start: " + total + " links | " + conc + " parallel", false);
        Store.setStatus("Running 0/" + total);
        CookieManager.getInstance().setAcceptCookie(true);
        pump();
    }

    void stop() {
        if (ended) return;
        stopped = true;
        for (Job j : new ArrayList<>(jobs)) destroy(j);
        jobs.clear();
        List<String> left = new ArrayList<>();
        for (Item it : failed) left.add(it.url);
        for (Item it : queue) left.add(it.url);
        queue.clear();
        Store.setFailed(left);
        Store.log("Stopped", true);
        finishAll("Stopped");
    }

    private void pump() {
        if (stopped || ended) return;
        while (jobs.size() < conc && !queue.isEmpty()) startJob(queue.poll());
        if (queue.isEmpty() && jobs.isEmpty()) endPass();
    }

    private void endPass() {
        if (!failed.isEmpty() && retryRound < 2) {
            retryRound++;
            Store.log("Retry round " + retryRound + ": " + failed.size() + " links", false);
            queue.addAll(failed);
            failed = new ArrayList<>();
            total = queue.size();
            doneCount = 0;
            label = "Retry " + retryRound;
            Store.setStatus(label + " 0/" + total);
            pump();
            return;
        }
        List<String> left = new ArrayList<>();
        for (Item it : failed) left.add(it.url);
        Store.setFailed(left);
        Store.log("Done ✓  Scraped: " + Store.results.size() + " | Failed: " + left.size(), false);
        finishAll("Done");
    }

    private void finishAll(String statusText) {
        if (ended) return;
        ended = true;
        Store.running = false;
        Store.setStatus(statusText);
        done.onDone();
    }

    private void startJob(Item item) {
        final Job j = new Job();
        j.item = item;
        WebView wv = new WebView(ctx);
        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setUserAgentString(DESKTOP_UA);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setLoadsImagesAutomatically(false);
        CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true);
        wv.setWebViewClient(new WebViewClient());
        wv.measure(View.MeasureSpec.makeMeasureSpec(1280, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(1600, View.MeasureSpec.EXACTLY));
        wv.layout(0, 0, 1280, 1600);
        j.wv = wv;
        jobs.add(j);
        wv.loadUrl(item.url);
        h.postDelayed(new Runnable() { @Override public void run() { tick(j); } }, 1500);
    }

    private void tick(final Job j) {
        if (stopped || j.finished) return;
        long elapsed = System.currentTimeMillis() - j.start;
        if (elapsed > MAX_MS) { complete(j, null); return; }
        if (j.evaluating) { later(j, 800); return; }
        j.evaluating = true;
        j.wv.evaluateJavascript(js, new android.webkit.ValueCallback<String>() {
            @Override public void onReceiveValue(String value) {
                j.evaluating = false;
                if (stopped || j.finished) return;
                JSONObject d = parse(value);
                long now = System.currentTimeMillis();
                boolean good = d != null
                        && !d.optString("Member Name").isEmpty()
                        && !d.optString("Member ID").isEmpty();
                if (good) {
                    if (!d.optString("Payer").isEmpty()) { complete(j, d); return; }
                    if (j.coreSince == 0) j.coreSince = now;
                    else if (now - j.coreSince > 5000) { complete(j, d); return; }
                } else {
                    long el = now - j.start;
                    if (el > 30000) {
                        String u = j.wv.getUrl();
                        if (u != null && !u.contains("verify-eligibility/transaction")) {
                            if (!loginWarned) {
                                loginWarned = true;
                                Store.log("Login expire lag raha hai — 'Login' dabao, login karo, phir dobara Start", true);
                            }
                            complete(j, null);
                            return;
                        }
                    }
                    if (el > 60000L * (j.reloaded + 1) && j.reloaded < 2) {
                        j.reloaded++;
                        j.coreSince = 0;
                        j.wv.reload();
                    }
                }
                later(j, 800);
            }
        });
    }

    private void later(final Job j, long ms) {
        h.postDelayed(new Runnable() { @Override public void run() { tick(j); } }, ms);
    }

    private JSONObject parse(String v) {
        if (v == null || v.equals("null")) return null;
        try { return new JSONObject(v); } catch (Exception e) { return null; }
    }

    private void complete(Job j, JSONObject data) {
        if (j.finished) return;
        j.finished = true;
        jobs.remove(j);
        destroy(j);
        doneCount++;
        if (data != null) {
            Store.addResult(j.item.seq, data);
            Store.log("✓ " + label + " " + doneCount + "/" + total + " — " + data.optString("Member Name"), false);
        } else {
            failed.add(j.item);
            Store.log(label + " " + doneCount + "/" + total + " — nahi hua (baad me retry)", true);
        }
        Store.setStatus("Running " + label + " " + doneCount + "/" + total);
        h.postDelayed(new Runnable() { @Override public void run() { pump(); } }, 200);
    }

    private void destroy(Job j) {
        j.finished = true;
        try {
            j.wv.stopLoading();
            j.wv.destroy();
        } catch (Exception ignored) { }
    }
}
