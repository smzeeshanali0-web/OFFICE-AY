package com.oabulk;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity implements Store.Listener {
    private static final int BG = Color.parseColor("#0f172a");
    private static final int CARD = Color.parseColor("#1e293b");
    private static final int TXT = Color.parseColor("#e2e8f0");
    private static final int MUTED = Color.parseColor("#94a3b8");

    private EditText ids, conc;
    private Button login, start, stop, export, clear;
    private TextView status, summary, failedTv, logTv, rowsTv;

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Store.init(this);
        buildUi();
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
    }

    private TextView label(String t) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextColor(MUTED);
        v.setTextSize(11);
        v.setAllCaps(true);
        v.setPadding(0, dp(10), 0, dp(4));
        return v;
    }

    private Button btn(String t, String color) {
        Button bt = new Button(this);
        bt.setText(t);
        bt.setAllCaps(false);
        bt.setTextColor(Color.WHITE);
        bt.setBackgroundColor(Color.parseColor(color));
        return bt;
    }

    private LinearLayout.LayoutParams weight() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        p.setMargins(dp(3), dp(3), dp(3), dp(3));
        return p;
    }

    private void buildUi() {
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(BG);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(36), dp(16), dp(24));
        sv.addView(root);

        TextView title = new TextView(this);
        title.setText("Oabulk — OfficeAlly Bulk");
        title.setTextColor(Color.parseColor("#38bdf8"));
        title.setTextSize(22);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(title);

        TextView sub = new TextView(this);
        sub.setText("Sirf Transaction ID paste karo • background me chalta hai");
        sub.setTextColor(MUTED);
        sub.setTextSize(12);
        root.addView(sub);

        login = btn("1) Login / OfficeAlly kholo", "#334155");
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(12);
        root.addView(login, lp);

        root.addView(label("Transaction IDs ya links (ek line me ek)"));
        ids = new EditText(this);
        ids.setHint("337035914-20261104\n337055423-20261104");
        ids.setHintTextColor(Color.parseColor("#64748b"));
        ids.setTextColor(Color.parseColor("#f1f5f9"));
        ids.setBackgroundColor(CARD);
        ids.setTypeface(Typeface.MONOSPACE);
        ids.setTextSize(13);
        ids.setMinLines(6);
        ids.setGravity(Gravity.TOP);
        ids.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        ids.setPadding(dp(10), dp(10), dp(10), dp(10));
        root.addView(ids, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        root.addView(label("Parallel (1-15) — shuru me 3 rakho"));
        conc = new EditText(this);
        conc.setText("3");
        conc.setTextColor(Color.parseColor("#f1f5f9"));
        conc.setBackgroundColor(CARD);
        conc.setInputType(InputType.TYPE_CLASS_NUMBER);
        conc.setPadding(dp(10), dp(8), dp(10), dp(8));
        root.addView(conc, new LinearLayout.LayoutParams(dp(90), ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        start = btn("▶ Start", "#2563eb");
        stop = btn("⏹ Stop", "#7f1d1d");
        row1.addView(start, weight());
        row1.addView(stop, weight());
        LinearLayout.LayoutParams r1 = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        r1.topMargin = dp(10);
        root.addView(row1, r1);

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        export = btn("⬇ CSV Download", "#065f46");
        clear = btn("Clear", "#334155");
        row2.addView(export, weight());
        row2.addView(clear, weight());
        root.addView(row2, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        status = new TextView(this);
        status.setTextColor(TXT);
        status.setTextSize(14);
        status.setTypeface(Typeface.DEFAULT_BOLD);
        status.setPadding(0, dp(12), 0, 0);
        root.addView(status);

        summary = new TextView(this);
        summary.setTextColor(MUTED);
        summary.setTextSize(13);
        root.addView(summary);

        root.addView(label("Log"));
        logTv = mono();
        root.addView(logTv);

        root.addView(label("Non-downloaded links"));
        failedTv = mono();
        failedTv.setTextIsSelectable(true);
        root.addView(failedTv);

        root.addView(label("Results (aakhri 50)"));
        rowsTv = mono();
        root.addView(rowsTv);

        setContentView(sv);

        login.setOnClickListener(v -> startActivity(new Intent(this, LoginActivity.class)));
        start.setOnClickListener(v -> onStart2());
        stop.setOnClickListener(v -> startService(new Intent(this, ScrapeService.class)
                .setAction(ScrapeService.ACTION_STOP)));
        export.setOnClickListener(v -> exportCsv());
        clear.setOnClickListener(v -> {
            if (!Store.running) {
                Store.logs.clear();
                Store.clearAll();
            }
        });
    }

    private TextView mono() {
        TextView t = new TextView(this);
        t.setTextColor(MUTED);
        t.setTextSize(11);
        t.setTypeface(Typeface.MONOSPACE);
        t.setBackgroundColor(CARD);
        t.setPadding(dp(8), dp(8), dp(8), dp(8));
        return t;
    }

    static List<String> parseInput(String text) {
        Pattern idp = Pattern.compile("\\d{6,}-\\d{8}");
        String baseTrim = Store.BASE_URL.replaceAll("/+$", "");
        LinkedHashSet<String> out = new LinkedHashSet<>();
        for (String raw : text.split("\\r?\\n")) {
            String line = raw.trim();
            if (line.isEmpty()) continue;
            Matcher m = idp.matcher(line);
            boolean found = false;
            while (m.find()) { out.add(Store.BASE_URL + m.group()); found = true; }
            if (found) continue;
            String[] tok = line.split("\\s+");
            String last = tok[tok.length - 1];
            if (last.toLowerCase().startsWith("http")) {
                if (!last.replaceAll("/+$", "").equals(baseTrim)) out.add(last);
            } else if (last.matches("^[A-Za-z0-9-]{5,}$")) {
                out.add(Store.BASE_URL + last);
            }
        }
        return new ArrayList<>(out);
    }

    private void onStart2() {
        List<String> urls = parseInput(ids.getText().toString());
        if (urls.isEmpty()) {
            Toast.makeText(this, "Pehle IDs ya links paste karo", Toast.LENGTH_SHORT).show();
            return;
        }
        int n = 3;
        try { n = Integer.parseInt(conc.getText().toString().trim()); } catch (Exception ignored) { }
        n = Math.max(1, Math.min(15, n));
        Store.pendingUrls = urls;
        Store.logs.clear();
        Store.running = true;
        Store.setStatus("Starting…");
        Intent i = new Intent(this, ScrapeService.class).setAction(ScrapeService.ACTION_START);
        i.putExtra("conc", n);
        startForegroundService(i);
    }

    private void exportCsv() {
        try {
            String name = "OfficeAlly_Bulk_" + Store.results.size() + "_" + System.currentTimeMillis() + ".csv";
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.Downloads.DISPLAY_NAME, name);
            cv.put(MediaStore.Downloads.MIME_TYPE, "text/csv");
            cv.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
            Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
            if (uri == null) throw new Exception("file nahi bani");
            try (OutputStream os = getContentResolver().openOutputStream(uri)) {
                os.write(Store.buildCsv().getBytes("UTF-8"));
            }
            Toast.makeText(this, "Downloads me save: " + name, Toast.LENGTH_LONG).show();

            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType("text/csv");
            share.putExtra(Intent.EXTRA_STREAM, uri);
            share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(share, "CSV share karo"));
        } catch (Exception e) {
            Toast.makeText(this, "Export error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        Store.listener = this;
        render();
    }

    @Override
    protected void onPause() {
        Store.listener = null;
        super.onPause();
    }

    @Override
    public void onChange() { render(); }

    private void render() {
        boolean r = Store.running;
        start.setEnabled(!r);
        stop.setEnabled(r);
        clear.setEnabled(!r);
        export.setEnabled(!Store.results.isEmpty() || !Store.failed.isEmpty());
        status.setText("Status: " + Store.status);
        summary.setText("Scraped: " + Store.results.size() + "   |   Failed: " + Store.failed.size());

        StringBuilder lg = new StringBuilder();
        for (String s : Store.logs) lg.append(s).append('\n');
        logTv.setText(lg.length() == 0 ? "—" : lg.toString().trim());

        StringBuilder f = new StringBuilder();
        for (String s : Store.failed) f.append(s).append('\n');
        failedTv.setText(f.length() == 0 ? "—" : f.toString().trim());

        List<JSONObject> rows = Store.sortedResults();
        StringBuilder rs = new StringBuilder();
        int from = Math.max(0, rows.size() - 50);
        for (int i = from; i < rows.size(); i++) {
            JSONObject d = rows.get(i).optJSONObject("d");
            if (d == null) continue;
            rs.append(i + 1).append(". ").append(d.optString("Member Name"))
                    .append(" | ").append(d.optString("Member ID"))
                    .append(" | ").append(d.optString("Payer"))
                    .append(" | ").append(d.optString("Coverage Status")).append('\n');
        }
        rowsTv.setText(rs.length() == 0 ? "—" : rs.toString().trim());
    }
}
