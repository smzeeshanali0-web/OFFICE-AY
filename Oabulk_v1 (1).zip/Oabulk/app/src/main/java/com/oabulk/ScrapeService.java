package com.oabulk;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.IBinder;
import android.os.PowerManager;

import java.util.ArrayList;
import java.util.List;

/** Foreground service: keeps scraping alive when the app is in the background. */
public class ScrapeService extends Service {
    static final String ACTION_START = "com.oabulk.START";
    static final String ACTION_STOP = "com.oabulk.STOP";
    private static final String CHANNEL = "oabulk";

    private ScrapeEngine engine;
    private PowerManager.WakeLock wakeLock;

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();

        if (ACTION_STOP.equals(action)) {
            if (engine != null) engine.stop();
            else stopSelf();
            return START_NOT_STICKY;
        }
        if (!ACTION_START.equals(action) || engine != null) {
            if (engine == null) stopSelf();
            return START_NOT_STICKY;
        }

        startForegroundCompat();

        List<String> urls = new ArrayList<>(Store.pendingUrls);
        Store.pendingUrls = new ArrayList<>();
        int conc = intent.getIntExtra("conc", 3);
        if (urls.isEmpty()) { stopSelf(); return START_NOT_STICKY; }

        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "oabulk:scrape");
        wakeLock.acquire(6 * 60 * 60 * 1000L);

        Store.running = true;
        engine = new ScrapeEngine(getApplicationContext(), conc, new ScrapeEngine.Done() {
            @Override public void onDone() {
                if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
                stopForeground(Service.STOP_FOREGROUND_REMOVE);
                engine = null;
                stopSelf();
            }
        });
        engine.start(urls);
        return START_NOT_STICKY;
    }

    private void startForegroundCompat() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Oabulk scraping",
                NotificationManager.IMPORTANCE_LOW));
        PendingIntent pi = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, CHANNEL)
                .setContentTitle("Oabulk")
                .setContentText("Scraping chal rahi hai…")
                .setSmallIcon(android.R.drawable.stat_sys_download)
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
    }

    @Override
    public void onDestroy() {
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        super.onDestroy();
    }
}
