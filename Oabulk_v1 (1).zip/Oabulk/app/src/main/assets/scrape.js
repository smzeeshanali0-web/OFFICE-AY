(function () {
  function T(el) { return (el && (el.innerText || el.textContent)) || ''; }
  var data = {
    'Transaction ID': '', 'Member Name': '', 'Member ID': '', 'Date of Birth': '',
    'Gender': '', 'Address': '', 'Group Number': '', 'Plan Begin Date': '',
    'Plan Name': '', 'Payer': '', 'Coverage Status': '', 'Identifier Code': ''
  };
  var m;
  var bodyText = T(document.body);

  var titleEl = document.querySelector('.summary__value');
  if (titleEl) {
    var t = T(titleEl).trim();
    if (/Transaction ID/i.test(t)) data['Transaction ID'] = t.replace(/Transaction ID:?/i, '').trim();
  }
  if (!data['Transaction ID']) {
    m = bodyText.match(/Transaction ID[:\s]*([A-Z0-9\-]+)/i);
    if (m) data['Transaction ID'] = m[1].trim();
  }

  document.querySelectorAll('.summary__group').forEach(function (group) {
    var label = T(group.querySelector('.summary__label')).trim();
    var value = T(group.querySelector('.summary__value')).trim().replace(/\n+/g, ' ');
    if (!label || !value) return;
    var l = label.toLowerCase();
    if (l.includes('member name') || l === 'name') data['Member Name'] = value;
    else if (l.includes('member id') || l.includes('subscriber id') || l === 'id') data['Member ID'] = value;
    else if (l.includes('date of birth') || l.includes('dob') || l.includes('birth')) data['Date of Birth'] = value;
    else if (l.includes('gender') || l.includes('sex')) data['Gender'] = value;
    else if (l.includes('address')) data['Address'] = value;
    else if (l.includes('group number') || l.includes('group #') || l.includes('group id')) data['Group Number'] = value;
    else if (l.includes('plan begin') || l.includes('effective') || l.includes('start date')) data['Plan Begin Date'] = value;
    else if (l.includes('plan name') || l.includes('plan type')) data['Plan Name'] = value;
    else if (l.includes('identifier code') || l.includes('identifier')) data['Identifier Code'] = value;
    else if (l.includes('transaction')) data['Transaction ID'] = data['Transaction ID'] || value;
    else data[label] = value;
  });

  var body = bodyText;
  if (!data['Member Name']) { m = body.match(/Member Name[:\s]*([^\n]+)/i); if (m) data['Member Name'] = m[1].trim(); }
  if (!data['Member ID']) { m = body.match(/(?:Member ID|Subscriber ID)[:\s]*([A-Z0-9\-]+)/i); if (m) data['Member ID'] = m[1].trim(); }
  if (!data['Date of Birth']) { m = body.match(/(?:Date of Birth|DOB)[:\s]*([0-9\/\-]+)/i); if (m) data['Date of Birth'] = m[1].trim(); }
  if (!data['Gender']) { m = body.match(/Gender[:\s]*(Male|Female|M|F|Other)/i); if (m) data['Gender'] = m[1].trim(); }
  if (!data['Address']) { m = body.match(/Address[:\s]*([^\n]+)/i); if (m) data['Address'] = m[1].trim(); }
  if (!data['Group Number']) { m = body.match(/Group (?:Number|#|ID)[:\s]*([A-Z0-9\-]+)/i); if (m) data['Group Number'] = m[1].trim(); }
  if (!data['Plan Begin Date']) { m = body.match(/(?:Plan Begin Date|Effective Date|Start Date)[:\s]*([0-9\/\-]+)/i); if (m) data['Plan Begin Date'] = m[1].trim(); }
  if (!data['Plan Name']) { m = body.match(/Plan Name[:\s]*([^\n]+)/i); if (m) data['Plan Name'] = m[1].trim(); }

  var payerBtn = document.querySelector('button.btn.payer, button.payer, .btn.payer');
  if (payerBtn) {
    var nameEl = payerBtn.querySelector('.fs-18, .fw-500, p:not(.payer__label)');
    if (nameEl) data['Payer'] = T(nameEl).trim();
    else {
      var all = T(payerBtn).replace(/Payer/i, '').replace(/Active Coverage|Inactive/i, '').trim();
      if (all) data['Payer'] = all;
    }
    var statusEl = payerBtn.querySelector('.payer__status, .payer__coverage');
    if (statusEl) data['Coverage Status'] = T(statusEl).trim();
  }
  if (!data['Coverage Status'] && /Active Coverage/i.test(body)) data['Coverage Status'] = 'Active Coverage';
  if (!data['Payer']) {
    m = body.match(/Payer[:\s]*([^\n]+)/i);
    if (m) data['Payer'] = m[1].replace(/Active Coverage|Inactive/i, '').trim();
  }

  if (!data['Identifier Code']) {
    var cands0 = Array.prototype.slice.call(document.querySelectorAll('.subgroup__title, .subgroup__pill, span, div, p, label'));
    var idTitle = cands0.find(function (el) { return /Identifier Code/i.test(T(el)) && T(el).trim().length < 40; });
    if (idTitle) {
      var group = idTitle.closest('.subgroup, .summary__group, [class*="subgroup"], [class*="group"]') || idTitle.parentElement;
      if (group) {
        var cands = group.querySelectorAll('.subgroup__value, .summary__value, .fs-14, .fs-16, .fw-500, span, p, div');
        for (var i = 0; i < cands.length; i++) {
          var txt = T(cands[i]).trim();
          if (txt && !/Identifier Code/i.test(txt) && txt.length > 1 && txt.length < 50) { data['Identifier Code'] = txt; break; }
        }
        if (!data['Identifier Code'] && idTitle.nextElementSibling) {
          var next = T(idTitle.nextElementSibling).trim();
          if (next && !/Identifier Code/i.test(next)) data['Identifier Code'] = next;
        }
      }
    }
    if (!data['Identifier Code']) {
      m = body.match(/Identifier Code[:\s]*([A-Z0-9\-]+)/i);
      if (m) data['Identifier Code'] = m[1].trim();
    }
  }
  return data;
})()
